import { QZ } from "qz-tray-types";

declare global {
  interface Window {
    qz?: QZ;
  }
}
